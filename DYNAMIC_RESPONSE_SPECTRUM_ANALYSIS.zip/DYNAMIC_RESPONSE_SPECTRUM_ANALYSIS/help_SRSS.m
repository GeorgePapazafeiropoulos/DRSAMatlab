%% SRSS
% Documentation of the SRSS function.

%% 
helpFun('SRSS')
