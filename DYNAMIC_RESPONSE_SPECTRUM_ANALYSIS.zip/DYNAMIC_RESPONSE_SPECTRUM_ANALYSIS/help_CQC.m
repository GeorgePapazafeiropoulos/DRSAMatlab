%% CQC
% Documentation of the CQC function.

%% 
helpFun('CQC')
