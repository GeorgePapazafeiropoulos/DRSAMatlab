%% DRSA
% Documentation of the DRSA function.

%% 
helpFun('DRSA')
