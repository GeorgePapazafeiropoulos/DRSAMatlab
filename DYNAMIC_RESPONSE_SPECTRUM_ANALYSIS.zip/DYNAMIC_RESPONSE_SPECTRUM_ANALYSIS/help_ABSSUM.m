%% ABSSUM
% Documentation of the ABSSUM function.

%% 
helpFun('ABSSUM')
